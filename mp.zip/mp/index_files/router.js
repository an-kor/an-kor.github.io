﻿WebMP.Router.map(function () {
    this.route('user_visitors');
    this.route('user_visited');
});
