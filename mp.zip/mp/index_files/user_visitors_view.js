﻿WebMP.UserVisitorsView = Ember.View.extend(WebMP.InfiniteScrollView, {
});