﻿WebMP.UserVisitedView = Ember.View.extend(WebMP.InfiniteScrollView, {
});