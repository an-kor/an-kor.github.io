var Messages = {
    "loadingDeals": "Laddar deals...",
    "searchDeal": "Sök deal",
    "myDeals": "Mina deals",
    "changeCity": "Ändra stad",
    "settings": "Inställningar"
};